#ifndef SAO_COMMON_SH
#define SAO_COMMON_SH

SAMPLER2D(u_source, 0);
uniform vec4 u_params[2];
uniform vec4 u_projection_infos; 

float linear_depth(float z) {
	return u_projection_infos.w / (z - u_projection_infos.z);
}

vec3 linear_depth(vec3 z) {
	return u_projection_infos.www / (z - u_projection_infos.zzz);
}

vec4 linear_depth(vec4 z) {
	return u_projection_infos.wwww / (z - u_projection_infos.zzzz);
}

vec3 unproject(vec2 pos, float depth) {
	return vec3((2.0*pos - 1.0) * u_projection_infos.xy * depth, depth);
}

#endif // SAO_COMMON_SH